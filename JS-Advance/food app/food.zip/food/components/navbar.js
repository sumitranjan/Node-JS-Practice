function navbar()
{
 
  return   ` <div class="left"></div>
        <div class="right">
      <div onclick="window.location.href='food.html'"> FoodMenu</div>
      <div onclick="window.location.href='latest.html'">Latest Receipe food</div>
      <div onclick="window.location.href='Reciepe.html'"> Receipe </div>
  </div>
  </div>`
  
 

}

export default navbar;




// function navbar(){


//   return ` <div id="navbar">
//   <div>
//     <h3> <a href="/">Home</a> </h3>
//   </div>
  
//   <div class="options">
//     <h3><a href="jewellery.html">Jewellery</a></h3>
//     <h3><a href="electronics.html">Electronics</a></h3>
//     <h3><a href="#">Register</a></h3>
//     <h3><a href="#">Login</a></h3>
  
//   </div>
//   </div>`
  
//   }
  
//   export default navbar;
  